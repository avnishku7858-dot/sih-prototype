import fetch from "node-fetch";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;

const CATEGORIES = ["Roads", "Water", "Sanitation", "Electricity", "Education", "Health", "Environment", "Public Safety", "Other"];

const DEPARTMENTS = {
  Roads: "Public Works Department",
  Water: "Water Supply Department",
  Sanitation: "Municipal Sanitation Department",
  Electricity: "Electricity Board",
  Education: "Education Department",
  Health: "Health Department",
  Environment: "Environment Department",
  "Public Safety": "Police / Disaster Management",
  Other: "General Administration",
};

function fallbackCategorize({ title, description }) {
  const text = `${title} ${description}`.toLowerCase();
  const rules = [
    { cat: "Roads", words: ["road", "pothole", "street", "traffic", "bridge"] },
    { cat: "Water", words: ["water", "pipe", "leak", "tap", "drinking"] },
    { cat: "Sanitation", words: ["garbage", "trash", "waste", "drain", "sewage", "toilet"] },
    { cat: "Electricity", words: ["electric", "power", "light", "wire", "transformer"] },
    { cat: "Education", words: ["school", "college", "teacher", "student", "education"] },
    { cat: "Health", words: ["hospital", "clinic", "doctor", "health", "disease"] },
    { cat: "Environment", words: ["tree", "pollution", "forest", "river", "air"] },
    { cat: "Public Safety", words: ["crime", "unsafe", "accident", "fire", "danger"] },
  ];
  const hit = rules.find((r) => r.words.some((w) => text.includes(w)));
  const category = hit ? hit.cat : "Other";
  const urgency = /urgent|danger|emergency|serious|severe/.test(text) ? "high" : "medium";
  return {
    category,
    urgency,
    summary: description.slice(0, 160),
    department: DEPARTMENTS[category] || "General Administration",
    byAI: false,
  };
}

const CHAT_FAQ = [
  { words: ["report", "citizen", "submit", "complain"], reply: "Sign in as a Citizen, click 'Report a problem', and add a title, description, location and photo/video evidence. Your report goes to Government for verification." },
  { words: ["verify", "government", "reject"], reply: "Government accounts review pending reports on the problem page and can Verify (moves it to Open) or Reject with a reason." },
  { words: ["claim", "university", "student", "solve"], reply: "University/Student accounts can claim any Open problem, then publish progress updates with evidence, and mark it Resolved when done." },
  { words: ["industry", "fund", "pledge", "mentor", "support"], reply: "Industry accounts can open a problem's Transparency tab and pledge Funding, Mentorship, Expertise or Resources." },
  { words: ["expense", "transparency", "money", "spend"], reply: "The Transparency tab on each problem shows itemized expenses (added by Government/University) and industry pledges, so spending stays public." },
  { words: ["leaderboard", "rank", "score"], reply: "The Leaderboard ranks university/student teams by how many problems they've claimed and resolved." },
  { words: ["login", "register", "account", "sign up", "password"], reply: "Use 'Sign in' at the top right to log in, or 'Create account' to register. Pick your role (Citizen, University, Industry or Government) when registering." },
  { words: ["ai", "category", "categoriz", "urgency"], reply: "When a citizen submits a report, AI (Gemini, with a rule-based fallback) automatically suggests a category, urgency level and routing department." },
];

function fallbackChat(message) {
  const text = (message || "").toLowerCase();
  const hit = CHAT_FAQ.find((f) => f.words.some((w) => text.includes(w)));
  if (hit) return hit.reply;
  return "I can help you with reporting problems, government verification, university solutions, industry support, transparency/expenses, and the leaderboard. Ask me about any of these!";
}

export async function chatWithAI({ message, history = [] }) {
  const trimmed = (message || "").trim();
  if (!trimmed) return { reply: "Ask me anything about how Awaaz Gram works.", byAI: false };
  if (!GEMINI_API_KEY) {
    return { reply: fallbackChat(trimmed), byAI: false };
  }
  try {
    const systemPrompt =
      "You are the Awaaz Gram help assistant. Awaaz Gram is a transparent platform connecting Citizens, Government, Universities/Students and Industry to report, verify, solve and fund real community problems. " +
      "Roles: Citizens report problems with photo/video evidence; Government verifies or rejects reports; University/Student teams claim verified problems, post progress updates and mark them resolved; Industry pledges funding, mentorship, expertise or resources. Every problem has a public Transparency tab with expenses and pledges, and a Leaderboard ranks teams by problems resolved. " +
      "Answer the visitor's question about how to use the platform in 2-4 short sentences. Be friendly, concise and specific. If asked something unrelated to the platform, politely redirect to platform topics.";
    const contents = [
      ...history.slice(-6).map((h) => ({ role: h.from === "bot" ? "model" : "user", parts: [{ text: h.text }] })),
      { role: "user", parts: [{ text: trimmed }] },
    ];
    const res = await fetch(GEMINI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ system_instruction: { parts: [{ text: systemPrompt }] }, contents }),
    });
    if (!res.ok) throw new Error("Gemini chat request failed: " + res.status);
    const data = await res.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    if (!text) throw new Error("Empty Gemini chat response");
    return { reply: text, byAI: true };
  } catch (e) {
    console.error("AI chat failed, using fallback:", e.message);
    return { reply: fallbackChat(trimmed), byAI: false };
  }
}

export async function categorizeWithAI({ title, description, location, imageBase64, mimeType }) {
  if (!GEMINI_API_KEY) {
    return fallbackCategorize({ title, description });
  }

  try {
    const parts = [
      {
        text:
          "You are a civic problem triage assistant. Reply with ONLY raw JSON, no markdown fences, no extra words.\n" +
          `Shape: {"category": one of ${JSON.stringify(CATEGORIES)}, "urgency": "low"|"medium"|"high", "summary": "one line under 25 words"}\n` +
          `Title: ${title}\nDescription: ${description}\nLocation: ${location}`,
      },
    ];
    if (imageBase64 && mimeType) {
      parts.push({ inline_data: { mime_type: mimeType, data: imageBase64 } });
    }

    const res = await fetch(GEMINI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts }] }),
    });
    if (!res.ok) throw new Error("Gemini request failed: " + res.status);

    const data = await res.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const clean = text.replace(/```json\s*/gi, "").replace(/```/g, "").trim();
    const parsed = JSON.parse(clean);

    const category = CATEGORIES.includes(parsed.category) ? parsed.category : "Other";
    return {
      category,
      urgency: ["low", "medium", "high"].includes(parsed.urgency) ? parsed.urgency : "medium",
      summary: parsed.summary || description.slice(0, 160),
      department: DEPARTMENTS[category] || "General Administration",
      byAI: true,
    };
  } catch (e) {
    console.error("AI categorization failed, using fallback:", e.message);
    return fallbackCategorize({ title, description });
  }
}
