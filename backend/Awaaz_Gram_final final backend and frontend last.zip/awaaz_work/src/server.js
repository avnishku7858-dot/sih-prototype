import "dotenv/config";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import cors from "cors";
import multer from "multer";
import { connectDb, db, usingMongo } from "./db.js";
import { categorizeWithAI, chatWithAI } from "./ai.js";
import { authMiddleware, requireRole, signUser, publicUser, hashPassword, checkPassword } from "./auth.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "").slice(0, 8) || ".bin";
    cb(null, Date.now() + "-" + Math.random().toString(36).slice(2, 8) + ext);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024, files: 6 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image|video)\//.test(file.mimetype);
    cb(ok ? null : new Error("Only photos and videos are allowed"), ok);
  },
});

const app = express();
const allowedOrigins = (process.env.CLIENT_ORIGIN || "http://localhost:5173")
  .split(",")
  .map((v) => v.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("CORS origin not allowed"));
  },
  credentials: true,
}));
app.use(express.json({ limit: "8mb" }));
app.use("/uploads", express.static(uploadDir));

function mediaFromFiles(req) {
  return (req.files || []).map((f) => ({
    kind: f.mimetype.startsWith("video") ? "video" : "image",
    url: "/uploads/" + f.filename,
    name: f.originalname,
  }));
}

function statusCounts(list) {
  const c = { total: list.length, pending_verification: 0, open: 0, in_progress: 0, resolved: 0, rejected: 0 };
  list.forEach((p) => {
    c[p.status] = (c[p.status] || 0) + 1;
  });
  return c;
}

// Simple in-memory rate limiter to slow down brute-force login/register attempts.
const attempts = new Map();
function authRateLimit(req, res, next) {
  const key = req.ip + ":" + req.path;
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  const max = 20;
  const entry = attempts.get(key) || { count: 0, resetAt: now + windowMs };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + windowMs;
  }
  entry.count += 1;
  attempts.set(key, entry);
  if (entry.count > max) {
    return res.status(429).json({ error: "Too many attempts. Please try again later." });
  }
  next();
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, db: usingMongo() ? "mongo" : "json", gemini: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/auth/register", authRateLimit, async (req, res) => {
  try {
    const { name, email, password, role, org, college } = req.body || {};
    const allowed = ["citizen", "university", "industry", "government"];
    if (!name?.trim() || !email?.trim() || !password || !allowed.includes(role)) {
      return res.status(400).json({ error: "Name, email, password and a valid role are required" });
    }
    if (String(password).length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters" });
    }
    if (await db.findUserByEmail(email)) return res.status(409).json({ error: "Email already registered" });
    const normalizedEmail = email.toLowerCase().trim();
    const user = await db.createUser({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash: await hashPassword(password),
      role,
      org: org || "",
      college: college || "",
    });
    const pub = publicUser(user);
    res.json({ token: signUser(user), user: pub });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/auth/login", authRateLimit, async (req, res) => {
  const { email, password } = req.body || {};
  const user = await db.findUserByEmail((email || "").toLowerCase().trim());
  if (!user || !(await checkPassword(password || "", user.passwordHash))) {
    return res.status(401).json({ error: "Email or password is incorrect" });
  }
  res.json({ token: signUser(user), user: publicUser(user) });
});

app.get("/api/auth/me", authMiddleware, (req, res) => {
  res.json({ user: req.user });
});

app.get("/api/problems", async (_req, res) => {
  res.json({ problems: await db.listProblems() });
});

app.get("/api/problems/:id", async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  res.json({ problem: p });
});

app.post("/api/problems", authMiddleware, requireRole("citizen"), upload.array("media", 6), async (req, res) => {
  try {
    const title = (req.body.title || "").trim();
    const description = (req.body.description || "").trim();
    const location = (req.body.location || "").trim() || "Not specified";
    if (!title || !description) return res.status(400).json({ error: "Add a title and description" });

    let imageBase64;
    let mimeType;
    const firstImg = (req.files || []).find((f) => f.mimetype.startsWith("image/"));
    if (firstImg) {
      imageBase64 = fs.readFileSync(firstImg.path).toString("base64");
      mimeType = firstImg.mimetype;
    }

    const ai = await categorizeWithAI({
      title,
      description,
      location,
      imageBase64,
      mimeType,
    });

    const problem = await db.createProblem({
      title,
      description,
      location,
      lat: req.body.lat ? Number(req.body.lat) : null,
      lng: req.body.lng ? Number(req.body.lng) : null,
      citizenName: req.user.name,
      citizenId: req.user.id,
      category: ai.category,
      urgency: ai.urgency,
      aiSummary: ai.summary,
      department: ai.department,
      byAI: ai.byAI,
      status: "pending_verification",
      media: mediaFromFiles(req),
      verification: null,
      rejection: null,
      assignment: null,
      updates: [],
      pledges: [],
      expenses: [],
      createdAt: new Date().toISOString(),
    });
    res.json({ problem });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/problems/:id/verify", authMiddleware, requireRole("government"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  p.status = "open";
  p.verification = { by: req.user.name, at: new Date().toISOString() };
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/reject", authMiddleware, requireRole("government"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  const reason = (req.body.reason || "").trim();
  if (!reason) return res.status(400).json({ error: "A reason is required" });
  p.status = "rejected";
  p.rejection = { reason, by: req.user.name, at: new Date().toISOString() };
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/claim", authMiddleware, requireRole("university"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  if (p.status !== "open") return res.status(400).json({ error: "This problem is not open" });
  p.status = "in_progress";
  p.assignment = { team: req.user.name, teamId: req.user.id, at: new Date().toISOString() };
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/updates", authMiddleware, requireRole("university"), upload.array("media", 3), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  const text = (req.body.text || "").trim();
  if (!text) return res.status(400).json({ error: "Write an update" });
  const files = mediaFromFiles(req);
  p.updates = p.updates || [];
  p.updates.push({
    text,
    by: req.user.name,
    at: new Date().toISOString(),
    mediaUrl: files[0]?.url || "",
  });
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/resolve", authMiddleware, requireRole("university"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  p.status = "resolved";
  p.updates = p.updates || [];
  p.updates.push({ text: "Marked resolved. Solution is with the community.", by: req.user.name, at: new Date().toISOString() });
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/pledges", authMiddleware, requireRole("industry"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  p.pledges = p.pledges || [];
  p.pledges.push({
    org: req.user.name,
    orgId: req.user.id,
    type: req.body.type || "Mentorship",
    note: req.body.note || "",
    amount: Number(req.body.amount || 0),
    at: new Date().toISOString(),
  });
  res.json({ problem: await db.saveProblem(p) });
});

app.post("/api/problems/:id/expenses", authMiddleware, requireRole("university", "government"), async (req, res) => {
  const p = await db.getProblem(req.params.id);
  if (!p) return res.status(404).json({ error: "Not found" });
  const item = (req.body.item || "").trim();
  const amount = Number(req.body.amount);
  if (!item || !amount) return res.status(400).json({ error: "Item and amount required" });
  p.expenses = p.expenses || [];
  p.expenses.push({ item, amount, by: req.user.name, at: new Date().toISOString() });
  res.json({ problem: await db.saveProblem(p) });
});

app.get("/api/stats", async (_req, res) => {
  const problems = await db.listProblems();
  const cats = {};
  problems.forEach((p) => {
    cats[p.category] = (cats[p.category] || 0) + 1;
  });
  const spent = problems.reduce((s, p) => s + (p.expenses || []).reduce((a, e) => a + Number(e.amount || 0), 0), 0);
  const pledged = problems.reduce((s, p) => s + (p.pledges || []).reduce((a, e) => a + Number(e.amount || 0), 0), 0);
  res.json({ counts: statusCounts(problems), categories: cats, spent, pledged });
});

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history } = req.body || {};
    if (typeof message !== "string" || message.length > 800) {
      return res.status(400).json({ error: "Message is required (max 800 characters)" });
    }
    const safeHistory = Array.isArray(history) ? history.slice(-6) : [];
    const result = await chatWithAI({ message, history: safeHistory });
    res.json(result);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/leaderboard", async (_req, res) => {
  const problems = await db.listProblems();
  const map = {};
  problems.forEach((p) => {
    const team = p.assignment?.team;
    if (!team) return;
    if (!map[team]) map[team] = { team, claimed: 0, resolved: 0, inProgress: 0 };
    map[team].claimed += 1;
    if (p.status === "resolved") map[team].resolved += 1;
    if (p.status === "in_progress") map[team].inProgress += 1;
  });
  const rows = Object.values(map).sort((a, b) => b.resolved - a.resolved || b.claimed - a.claimed);
  res.json({ rows });
});

// In production, serve the built React app from the same Node service.
// This gives Awaaz Gram one public URL, so phones can access it over the internet
// without sharing the developer laptop or being on the same Wi-Fi network.
const frontendDist = path.join(__dirname, "..", "frontend", "dist");
app.use(express.static(frontendDist));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/") || req.path.startsWith("/uploads/")) return next();
  res.sendFile(path.join(frontendDist, "index.html"), (err) => {
    if (err) next();
  });
});

app.use((err, _req, res, _next) => {
  const status = err.statusCode || (err.name === "MulterError" ? 400 : 500);
  console.error(err);
  res.status(status).json({ error: err.message || "Server error" });
});

const PORT = Number(process.env.PORT || 5050);
await connectDb();
app.listen(PORT, () => {
  console.log("Awaaz Gram API on http://localhost:" + PORT);
});
