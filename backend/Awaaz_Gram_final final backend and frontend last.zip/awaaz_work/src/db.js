import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import mongoose from "mongoose";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });
const dataFile = path.join(dataDir, "db.json");

let mongoConnected = false;
let UserModel, ProblemModel;

function loadJson() {
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify({ users: [], problems: [] }, null, 2));
  }
  return JSON.parse(fs.readFileSync(dataFile, "utf-8"));
}

function saveJson(data) {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

function newId() {
  return crypto.randomBytes(12).toString("hex");
}

// ---- Mongo schemas (only used if MONGODB_URI is set) ----
const UserSchema = new mongoose.Schema(
  {
    name: String,
    email: { type: String, unique: true },
    passwordHash: String,
    role: String,
    org: String,
    college: String,
  },
  { timestamps: true }
);
const ProblemSchema = new mongoose.Schema({}, { strict: false });

function idify(doc) {
  if (!doc) return null;
  const obj = doc.toObject ? doc.toObject() : doc;
  return { ...obj, id: String(obj._id || obj.id) };
}

export function usingMongo() {
  return mongoConnected;
}

export async function connectDb() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    loadJson();
    console.log("Awaaz Gram DB: using local JSON storage at " + dataFile);
    return;
  }
  try {
    await mongoose.connect(uri);
    UserModel = mongoose.models.User || mongoose.model("User", UserSchema);
    ProblemModel = mongoose.models.Problem || mongoose.model("Problem", ProblemSchema);
    mongoConnected = true;
    console.log("Awaaz Gram DB: connected to MongoDB");
  } catch (e) {
    console.error("MongoDB connect failed, falling back to JSON storage:", e.message);
    loadJson();
    mongoConnected = false;
  }
}

export const db = {
  async findUserByEmail(email) {
    if (usingMongo()) return idify(await UserModel.findOne({ email }));
    const data = loadJson();
    return data.users.find((u) => u.email === email) || null;
  },

  async createUser(fields) {
    if (usingMongo()) return idify(await UserModel.create(fields));
    const data = loadJson();
    const user = { id: newId(), ...fields, createdAt: new Date().toISOString() };
    data.users.push(user);
    saveJson(data);
    return user;
  },

  async listProblems() {
    if (usingMongo()) {
      const docs = await ProblemModel.find().sort({ createdAt: -1 });
      return docs.map(idify);
    }
    const data = loadJson();
    return [...data.problems].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  },

  async getProblem(id) {
    if (usingMongo()) {
      if (!mongoose.isValidObjectId(id)) return null;
      return idify(await ProblemModel.findById(id));
    }
    const data = loadJson();
    return data.problems.find((p) => p.id === id) || null;
  },

  async createProblem(fields) {
    if (usingMongo()) return idify(await ProblemModel.create(fields));
    const data = loadJson();
    const problem = { id: newId(), ...fields };
    data.problems.push(problem);
    saveJson(data);
    return problem;
  },

  async saveProblem(problem) {
    if (usingMongo()) {
      const { id, _id, ...rest } = problem;
      const doc = await ProblemModel.findByIdAndUpdate(id, rest, { new: true });
      return idify(doc);
    }
    const data = loadJson();
    const idx = data.problems.findIndex((p) => p.id === problem.id);
    if (idx === -1) throw new Error("Problem not found");
    data.problems[idx] = problem;
    saveJson(data);
    return problem;
  },
};
