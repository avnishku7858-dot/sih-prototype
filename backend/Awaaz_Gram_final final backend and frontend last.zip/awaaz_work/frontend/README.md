# Awaaz Gram Frontend

Professional React + Vite frontend for the Awaaz Gram public-impact platform.

## Run locally

From this `frontend` folder:

```bash
npm install
npm run dev
```

The UI uses `http://localhost:5050` as the default backend. To change it, create `frontend/.env`:

```env
VITE_API_URL=http://localhost:5050
```

## Main flows

- Public problem discovery and search/filtering
- Citizen report flow with photo/video upload and browser location capture
- AI routing status and problem metadata
- Government verification/rejection
- University claim, progress update with evidence, and resolution
- Industry mentorship/funding/expertise pledges
- Public expense ledger
- Role-aware dashboards
- Collaboration leaderboard
- Responsive mobile/tablet/desktop UI
