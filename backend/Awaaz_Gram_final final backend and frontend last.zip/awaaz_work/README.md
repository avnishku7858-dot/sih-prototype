# Awaaz Gram Backend — Fixed

This ZIP intentionally keeps the same backend structure you provided.

## Run

```bash
npm install
npm run dev
```

Then open `http://localhost:5050/api/health`.

## Important

- This ZIP contains the **backend only**. The frontend was not present in the supplied ZIP, so it was not replaced or redesigned.
- Before using the project, change `JWT_SECRET` in `.env` to a private random value of at least 32 characters.
- `GEMINI_API_KEY` is optional. If it is empty, Awaaz Gram still works with the built-in categorization fallback.
- The AI model is configurable through `GEMINI_MODEL`; the default is `gemini-3.8-flash`.
- Local development uses `data/db.json` when `MONGODB_URI` is empty.

## Main API

- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/problems`
- `POST /api/problems` (citizen)
- `POST /api/problems/:id/verify` (government)
- `POST /api/problems/:id/reject` (government)
- `POST /api/problems/:id/claim` (university)
- `POST /api/problems/:id/updates` (university)
- `POST /api/problems/:id/resolve` (university)
- `POST /api/problems/:id/pledges` (industry)
- `POST /api/problems/:id/expenses` (university/government)
- `GET /api/stats`
- `GET /api/leaderboard`

## Frontend

The `frontend/` directory is a React + Vite interface for the Awaaz Gram backend. Run the backend with `npm run dev`, then in a second terminal run `npm install --prefix frontend` and `npm run dev --prefix frontend`. The frontend expects the backend at `http://localhost:5050` by default; set `frontend/.env` with `VITE_API_URL` if needed.
